# Phase2 Design Marketing

This folder contains assets, prompts, and documentation for phase2 design marketing.